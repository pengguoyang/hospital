package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.SchedulingDao;
import com.hospital.entity.Scheduling;
import com.hospital.service.SchedulingService;
@Service("schedulingService")
public class SchedulingServiceImpl implements SchedulingService{
	@Resource
	private SchedulingDao schedulingDao;
	
	public List<Scheduling> getSchedulingByStaid(Integer staid) {
		// TODO Auto-generated method stub
		return schedulingDao.getSchedulingByStaid(staid);
	}

	public int deleteBydepid(Map<String,Object> map) {
		// TODO Auto-generated method stub
		return schedulingDao.deleteBydepid(map);
	}

	public int insertScheduling(Scheduling scheduling) {
		// TODO Auto-generated method stub
		return schedulingDao.insertScheduling(scheduling);
	}

}
