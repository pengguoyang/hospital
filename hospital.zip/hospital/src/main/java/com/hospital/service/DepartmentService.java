package com.hospital.service;



import java.util.List;

import com.hospital.entity.Department;

public interface DepartmentService {
	/**
	 * ͨ��id��ÿ���
	 * @param id
	 * @return
	 */
	public Department getDepartmentById(int  id);
	/**
	 * ��ѯ�����п���
	 * @return
	 */
	public List<Department> showDepartmentList();
}
