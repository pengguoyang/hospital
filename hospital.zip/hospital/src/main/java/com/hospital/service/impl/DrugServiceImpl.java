package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hospital.dao.DrugDao;
import com.hospital.entity.Drug;
import com.hospital.service.DrugService;

@Service
@RequestMapping("drugService")
public class DrugServiceImpl implements DrugService{
	@Resource
	private DrugDao drugDao;
	
	public Drug getDrugById(Integer drugid) {
		// TODO Auto-generated method stub
		return drugDao.getDrugById(drugid);
	}

	public Drug getDrugByName(String drugname) {
		// TODO Auto-generated method stub
		return drugDao.getDrugByName(drugname);
	}

	public Integer addDrug(Drug drug) {
		// TODO Auto-generated method stub
		return drugDao.addDrug(drug);
	}

	public List<Drug> showDrugList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return drugDao.showDrugList(map);
	}

	public Integer getSumByDrugName(String drugname) {
		// TODO Auto-generated method stub
		return drugDao.getSumByDrugName(drugname);
	}

	public Integer updateDrug(Drug drug) {
		// TODO Auto-generated method stub
		return drugDao.updateDrug(drug);
	}

	public Integer getPayByDrugid(Integer drugid) {
		// TODO Auto-generated method stub
		return drugDao.getPayByDrugid(drugid);
	}

	public Integer getDrugTotal(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return drugDao.getDrugTotal(map);
	}

}
