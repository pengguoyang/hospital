package com.hospital.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.PrescriptiondetailDao;
import com.hospital.entity.Prescriptiondetail;
import com.hospital.service.PrescriptiondetailService;
@Service("prescriptiondetailService")
public class PrescriptiondetailServiceImpl implements PrescriptiondetailService{
	@Resource
	private PrescriptiondetailDao prescriptiondetailDao;
	
	public int addPrescriptiondetail(Prescriptiondetail prescriptiondetail) {
		// TODO Auto-generated method stub
		return prescriptiondetailDao.addPrescriptiondetail(prescriptiondetail);
	}

	public Prescriptiondetail getPrescriptiondetailById(int detId) {
		// TODO Auto-generated method stub
		return prescriptiondetailDao.getPrescriptiondetailById(detId);
	}

	public List<Prescriptiondetail> getPrescriptiondetailByPreid(int preid) {
		// TODO Auto-generated method stub
		return prescriptiondetailDao.getPrescriptiondetailByPreid(preid);
	}

	public Integer deleteByPreId(int preid) {
		// TODO Auto-generated method stub
		return prescriptiondetailDao.deleteByPreId(preid);
	}

}
