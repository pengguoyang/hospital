package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.PatientDao;
import com.hospital.entity.Patient;
import com.hospital.service.PatientService;
@Service("patientService")
public class PatientServiceImpl  implements PatientService{
	@Resource
	private PatientDao patientDao;
	
	public Patient getPatientByCard(String patcard) {
		// TODO Auto-generated method stub
		return patientDao.getPatientByCard(patcard);
	}

	public Patient getPatientById(Integer id) {
		// TODO Auto-generated method stub
		return patientDao.getPatientById(id);
	}

	public int updatePatient(Patient patient) {
		// TODO Auto-generated method stub
		return patientDao.updatePatient(patient);
	}

	public int addPatient(Patient patient) {
		// TODO Auto-generated method stub
		return patientDao.addPatient(patient);
	}

	public List<Patient> showPatientList(Map<String,Object> map) {
		// TODO Auto-generated method stub
		return patientDao.showPatientList(map);
	}

	public Integer patientTotal() {
		// TODO Auto-generated method stub
		return patientDao.patientTotal();
	}

	public List<Patient> showRegistrationPatientList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return patientDao.showRegistrationPatientList(map);
	}

	public Integer registrationPatientTotal(Integer staid) {
		// TODO Auto-generated method stub
		return patientDao.registrationPatientTotal(staid);
	}

}
