package com.hospital.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.DepartmentDao;
import com.hospital.entity.Department;
import com.hospital.service.DepartmentService;
@Service("departmentService")
public class DepartmentServiceImpl implements DepartmentService{
	@Resource
	private DepartmentDao departDao;
	
	public Department getDepartmentById(int id) {
		// TODO Auto-generated method stub
		return departDao.getDepartmentById(id);
	}

	public List<Department> showDepartmentList() {
		// TODO Auto-generated method stub
		return departDao.showDepartmentList();
	}

}
