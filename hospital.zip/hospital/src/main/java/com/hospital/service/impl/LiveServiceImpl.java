package com.hospital.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.LiveDao;
import com.hospital.entity.Live;
import com.hospital.service.LiveService;
@Service("liveService")
public class LiveServiceImpl implements LiveService{
	@Resource
	private LiveDao liveDao;
	public int addLive(Live live) {
		// TODO Auto-generated method stub
		return liveDao.addLive(live);
	}
	public Live getLiveById(Integer id) {
		// TODO Auto-generated method stub
		return liveDao.getLiveById(id);
	}
	public Live getLiveBypatId(Integer patid) {
		// TODO Auto-generated method stub
		return liveDao.getLiveBypatId(patid);
	}
	public Integer updateLive(Live live) {
		// TODO Auto-generated method stub
		return liveDao.updateLive(live);
	}
	public Integer getLiveIncome(Integer depid) {
		// TODO Auto-generated method stub
		return liveDao.getLiveIncome(depid);
	}

}
