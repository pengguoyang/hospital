package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.RoleDao;
import com.hospital.entity.Role;
import com.hospital.service.RoleService;

@Service("roleService")
public class RoleServiceImpl implements RoleService{
	@Resource
	private RoleDao roleDao;
	
	public Role getRoleById(int id) {
		// TODO Auto-generated method stub
		return roleDao.getRoleById(id);
	}

	public List<Role> showRoleList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return roleDao.showRoleList(map);
	}

	public Integer RoleTotal() {
		// TODO Auto-generated method stub
		return roleDao.RoleTotal();
	}

	public Integer updateRole(Role role) {
		// TODO Auto-generated method stub
		return roleDao.updateRole(role);
	}

	public Integer getSalByRoleid(Integer roleid) {
		// TODO Auto-generated method stub
		return roleDao.getSalByRoleid(roleid);
	}

}
