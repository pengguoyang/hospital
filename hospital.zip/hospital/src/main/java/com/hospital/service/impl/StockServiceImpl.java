package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hospital.dao.StockDao;
import com.hospital.entity.Stock;
import com.hospital.service.StockService;

@Service("stockService")
public class StockServiceImpl implements StockService{
	@Resource
	private StockDao stockDao;

	public List<Stock> showStockList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return stockDao.showStockList(map);
	}

	public Integer getStockTotal() {
		// TODO Auto-generated method stub
		return stockDao.getStockTotal();
	}

	public Stock getStockById(Integer stoid) {
		// TODO Auto-generated method stub
		return stockDao.getStockById(stoid);
	}

	public Integer updateStock(Stock stock) {
		// TODO Auto-generated method stub
		return stockDao.updateStock(stock);
	}

	public Integer addStock(Stock stock) {
		// TODO Auto-generated method stub
		return stockDao.addStock(stock);
	}

	public List<Stock> showAllStockList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return stockDao.showAllStockList(map);
	}

	public Integer deleteStock(Integer stoid) {
		// TODO Auto-generated method stub
		return stockDao.deleteStock(stoid);
	}
	
	

}
