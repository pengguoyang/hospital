package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.RecordDao;
import com.hospital.entity.Record;
import com.hospital.service.RecordService;
@Service("recordService")
public class RecordServiceImpl implements RecordService{
	@Resource
	private RecordDao recordDao;
	public int addRecord(Record record) {
		// TODO Auto-generated method stub
		return recordDao.addRecord(record);
	}
	public Record getRecordById(int recid) {
		// TODO Auto-generated method stub
		return recordDao.getRecordById(recid);
	}
	public List<Record> showRecordList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return recordDao.showRecordList(map);
	}
	public Integer getRecordTotal(Integer staid) {
		// TODO Auto-generated method stub
		return recordDao.getRecordTotal(staid);
	}
	public Integer updateRecord(Record record) {
		// TODO Auto-generated method stub
		return recordDao.updateRecord(record);
	}

}
