package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.BedDao;
import com.hospital.entity.Bed;
import com.hospital.service.BedService;
@Service("BedService")
public class BedServiceImpl implements BedService{
	@Resource
	private BedDao bedDao;
	public List<Bed> list(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return bedDao.list(map);
	}

	public Bed getBedById(int id) {
		// TODO Auto-generated method stub
		return bedDao.getBedById(id);
	}

	public int updateBed(Bed bed) {
		// TODO Auto-generated method stub
		return bedDao.updateBed(bed);
	}

	public Integer BedTotal(Integer depid) {
		// TODO Auto-generated method stub
		return bedDao.BedTotal(depid);
	}

	public Integer userBedTotal(Integer depid) {
		// TODO Auto-generated method stub
		return bedDao.userBedTotal(depid);
	}

	public Bed getBedByPatId(int patid) {
		// TODO Auto-generated method stub
		return bedDao.getBedByPatId(patid);
	}

	public int updateBedSetNull(int bedid) {
		// TODO Auto-generated method stub
		return bedDao.updateBedSetNull(bedid);
	}

	public int addBed(Bed bed) {
		// TODO Auto-generated method stub
		return bedDao.addBed(bed);
	}

	public int getNumberByWardid(int wardid) {
		// TODO Auto-generated method stub
		return bedDao.getNumberByWardid(wardid);
	}

}
