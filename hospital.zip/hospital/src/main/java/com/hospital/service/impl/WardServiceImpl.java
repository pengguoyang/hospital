package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.WardDao;
import com.hospital.entity.Ward;
import com.hospital.service.WardService;
@Service("wardService")
public class WardServiceImpl implements WardService{
	@Resource
	private  WardDao wardDao;
	
	public Ward getWardById(int id) {
		// TODO Auto-generated method stub
		return wardDao.getWardById(id);
	}

	public List<Ward> showWardList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return wardDao.showWardList(map);
	}

	public Integer addWard(Ward ward) {
		// TODO Auto-generated method stub
		return wardDao.addWard(ward);
	}

	public Integer getWardTotal() {
		// TODO Auto-generated method stub
		return wardDao.getWardTotal();
	}

}
