package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.PrescriptionDao;
import com.hospital.entity.Prescription;
import com.hospital.service.PrescriptionService;
@Service("prescriptionService")
public class PrescriptionServiceImpl implements PrescriptionService{
	@Resource
	private PrescriptionDao prescriptionDao;
	public int addPrescription(Prescription prescription) {
		// TODO Auto-generated method stub
		return prescriptionDao.addPrescription(prescription);
	}

	public Prescription getPrescriptionById(int preId) {
		// TODO Auto-generated method stub
		return prescriptionDao.getPrescriptionById(preId);
	}

	public List<Prescription> showPrescriptionList(Map map) {
		// TODO Auto-generated method stub
		return prescriptionDao.showPrescriptionList(map);
	}

	public Integer PrescriptionTotal() {
		// TODO Auto-generated method stub
		return prescriptionDao.PrescriptionTotal();
	}

	public Integer updateToget(Integer preid) {
		// TODO Auto-generated method stub
		return prescriptionDao.updateToget(preid);
	}

	public Integer deleteByPreId(Integer preid) {
		// TODO Auto-generated method stub
		return prescriptionDao.deleteByPreId(preid);
	}

	public Integer getPreIncomeByDepid(Integer depid) {
		// TODO Auto-generated method stub
		return prescriptionDao.getPreIncomeByDepid(depid);
	}

}
