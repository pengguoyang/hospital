package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.StaffDao;
import com.hospital.entity.Staff;
import com.hospital.service.StaffService;

@Service("staffService")
public class StaffServiceImpl implements StaffService{
	@Resource
	private StaffDao staffDao;
	
	public Staff login(Map<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return staffDao.login(paramMap);
	}

	public Staff getStaffById(Integer id) {
		// TODO Auto-generated method stub
		return staffDao.getStaffById(id);
	}

	public List<Staff> showDoctorByDepid(Map<String,Object> map) {
		// TODO Auto-generated method stub
		return staffDao.showDoctorByDepid(map);
	}

	public Integer doctorByDepidTotal(Integer depid) {
		// TODO Auto-generated method stub
		return staffDao.doctorByDepidTotal(depid);
	}

	public Integer updateInfo(Staff staff) {
		// TODO Auto-generated method stub
		return staffDao.updateInfo(staff);
	}

	public Staff getStaffByStaphone(String staphone) {
		// TODO Auto-generated method stub
		return staffDao.getStaffByStaphone(staphone);
	}

	public List<Staff> getStaffByDepid(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return staffDao.getStaffByDepid(map);
	}

	public List<Staff> showAllStaff(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return staffDao.showAllStaff(map);
	}

	public Integer StaffTotal() {
		// TODO Auto-generated method stub
		return staffDao.StaffTotal();
	}

	public Integer addStaff(Staff staff) {
		// TODO Auto-generated method stub
		return staffDao.addStaff(staff);
	}

	public Integer getNumByRoleid(Integer roleid) {
		// TODO Auto-generated method stub
		return staffDao.getNumByRoleid(roleid);
	}


}
