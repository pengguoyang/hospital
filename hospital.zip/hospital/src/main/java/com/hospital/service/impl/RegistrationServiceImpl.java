package com.hospital.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hospital.dao.RegistrationDao;
import com.hospital.entity.Registration;
import com.hospital.service.RegistrationService;
@Service("registrationService")
public class RegistrationServiceImpl implements RegistrationService{
	@Resource
	private RegistrationDao registrationDao;
	public int addRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return registrationDao.addRegistration(registration);
	}
	public List<Registration> showRegistrationList(Map<String,Object> map) {
		// TODO Auto-generated method stub
		return registrationDao.showRegistrationList(map);
	}
	public Integer registrationTotal() {
		// TODO Auto-generated method stub
		return registrationDao.registrationTotal();
	}
	public Integer updBreak(Integer regid) {
		// TODO Auto-generated method stub
		return registrationDao.updBreak(regid);
	}
	public Registration getRegistrationByRegid(Integer id) {
		// TODO Auto-generated method stub
		return registrationDao.getRegistrationByRegid(id);
	}
	public Integer updateRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return registrationDao.updateRegistration(registration);
	}
	public Integer updBreakByPatid(Map<String,Object> map) {
		// TODO Auto-generated method stub
		return registrationDao.updBreakByPatid(map);
	}

}
