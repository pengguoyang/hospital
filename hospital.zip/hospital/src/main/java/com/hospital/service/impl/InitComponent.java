package com.hospital.service.impl;

public class InitComponent {
}
