package com.hospital.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Department;
import com.hospital.entity.DepartmentIncome;
import com.hospital.entity.Drug;
import com.hospital.entity.DrugDTO;
import com.hospital.entity.Role;
import com.hospital.entity.RoleDTO;
import com.hospital.service.DepartmentService;
import com.hospital.service.DrugService;
import com.hospital.service.LiveService;
import com.hospital.service.PrescriptionService;
import com.hospital.service.RoleService;
import com.hospital.service.StaffService;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@RequestMapping("finance")
@Controller
public class FinanceController {
	@Resource
	private RoleService roleService;
	@Resource
	private StaffService staffService;
	@Resource
	private DepartmentService departmentService;
	@Resource
	private LiveService liveService;
	@Resource
	private PrescriptionService PrescriptionService;
	@Resource
	private DrugService drugService;
	@RequestMapping("ShowRoleSalSum")
	public String ShowRoleSalSum(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,
			HttpServletResponse resp) throws Exception {
		Integer roleNum=0;
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		List<Role> showRoleList = roleService.showRoleList(map);
		Integer total=roleService.RoleTotal();
		List<RoleDTO> roleDTOList=new ArrayList<RoleDTO>();
		for (Role role : showRoleList) {
			if(role.getRoleid()!=1) {
				RoleDTO roleDTO = new RoleDTO();
				roleDTO.setRoleid(role.getRoleid());
				roleDTO.setRolename(role.getRolename());
				roleDTO.setRolesal(role.getRolesal());
				roleNum=staffService.getNumByRoleid(role.getRoleid());
				roleDTO.setSalsum(roleNum*role.getRolesal());
				roleDTOList.add(roleDTO);
			}
		}
		JSONObject result=new JSONObject();
		JSONArray array=JSONArray.fromObject(roleDTOList);
		result.put("rows", array);
		result.put("total",total );
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("ShowDepartmentIncome")
	public String ShowDepartmentIncome(HttpServletResponse resp) throws Exception {
		Integer liveIncome=0;
		Integer PrescriptionIncome=0;
		List<Department> showDepartmentList = departmentService.showDepartmentList();
		List<DepartmentIncome> incomeList=new ArrayList<DepartmentIncome>();
		for (Department dep: showDepartmentList) {
			DepartmentIncome depIncome = new DepartmentIncome();
			depIncome.setDepid(dep.getDepid());
			depIncome.setDepname(dep.getDepname());
			liveIncome=liveService.getLiveIncome(dep.getDepid());
			depIncome.setLiveIncome(liveIncome);
			PrescriptionIncome=PrescriptionService.getPreIncomeByDepid(dep.getDepid());
			depIncome.setPrescriptionIncome(PrescriptionIncome);
			depIncome.setIncome(liveIncome+PrescriptionIncome);
			incomeList.add(depIncome);
		}
		JSONObject result=new JSONObject();
		JSONArray array=JSONArray.fromObject(incomeList);
		result.put("rows", array);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("ShowDrugExpend")
	public String ShowDrugExpend(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String drugname,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("drugname",StringUtil.formatLike(drugname));
		List<Drug> drugList = drugService.showDrugList(map);
		List<DrugDTO> drugDTOList=new ArrayList<DrugDTO>();
		for (Drug drug : drugList) {
			int drugnum=drugService.getSumByDrugName(drug.getDrugname());
			Integer payByDrugid = drugService.getPayByDrugid(drug.getDrugid());
			drug.setDrugpay(payByDrugid);
			DrugDTO drugDTO = new DrugDTO(drug.getDrugid(), drug.getDrugname(), drug.getDrugbrand(),drug.getDrugnote(),drug.getDrugtype(),drug.getDrugpay(), drugnum);
			drugDTOList.add(drugDTO);
		}
		Integer total = drugService.getDrugTotal(map);
		JSONObject result=new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(drugDTOList);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
}
