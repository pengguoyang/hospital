package com.hospital.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Patient;
import com.hospital.entity.Prescription;
import com.hospital.entity.Prescriptiondetail;
import com.hospital.entity.Record;
import com.hospital.entity.Staff;
import com.hospital.entity.Stock;
import com.hospital.service.PatientService;
import com.hospital.service.PrescriptionService;
import com.hospital.service.PrescriptiondetailService;
import com.hospital.service.RecordService;
import com.hospital.service.RegistrationService;
import com.hospital.service.StockService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("Record")
public class RecordController {
	@Resource
	private PatientService patientService;
	@Resource
	private RecordService recordService;
	@Resource
	private PrescriptionService prescriptionService;
	@Resource
	private PrescriptiondetailService prescriptiondetailService;
	@Resource
	private StockService stockService;
	@Resource
	private RegistrationService registrationService;
	@RequestMapping("recordInit")
	public String writeRecordInit(int patid,HttpServletRequest req,HttpServletResponse resp) throws Exception {
		//�������һ��������ص�session
		HttpSession session = req.getSession();
		session.removeAttribute("stockDTOList");
		session.removeAttribute("PrescriptiondetailList");
		session.removeAttribute("pastdisease");
		session.removeAttribute("reccontent");
		Patient patientById = patientService.getPatientById(patid);
		JSONObject result=new JSONObject();
		if(patientById!=null) {
			session.setAttribute("patid", patientById.getPatid());
			session.setAttribute("patname", patientById.getPatname());
			session.setAttribute("patsex", patientById.getPatsex());
			session.setAttribute("patage", patientById.getPatage());
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("saveRecordInfo")
	public String saveRecord(HttpServletResponse resp,HttpServletRequest req,String pastdisease,String reccontent) throws Exception {
		HttpSession session = req.getSession();
		session.setAttribute("pastdisease", pastdisease);
		session.setAttribute("reccontent",reccontent);
		JSONObject result=new JSONObject();
		result.put("success",Boolean.valueOf(true));
		ResponseUtil.write(resp, result);
		return null;
	}
	
	
	
	@RequestMapping("saveRecord")
	public String saveRecord(Patient patient,Record record,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		HttpSession session=req.getSession();
		int count=0;
		//����һ��������¼������ֵid
		Staff staff=(Staff)session.getAttribute("staff");
		record.setStaff(staff);
		Integer patid=patient.getPatid();
		Patient patientById = patientService.getPatientById(patid);
		record.setPatient(patientById);
		record.setRectime(new Date());
		recordService.addRecord(record);
		//����һ��������Ϣ
		Prescription prescription=new Prescription(null, new Date(), record, false);
		count=prescriptionService.addPrescription(prescription);
		//������Ӧ�Ĵ��������¼������ȥ��Ӧ��ҩƷ����
		List<Prescriptiondetail> PreList=(List<Prescriptiondetail>)session.getAttribute("PrescriptiondetailList");
		for (Prescriptiondetail pre: PreList) {
			pre.setPrescription(prescription);
			prescriptiondetailService.addPrescriptiondetail(pre);
			//�õ���Ӧ�Ŀ��id�����Զ�ӦҩƷ��ȥ��������
			Integer stoid=pre.getStock().getStoid();
			Stock stock = stockService.getStockById(stoid);
			Integer poor=stock.getDrugnum()-pre.getDrugnumber();
			stock.setDrugnum(poor);
			stockService.updateStock(stock);
		}
		JSONObject result=new JSONObject();
		//������ӳɹ��򷵻�true��ʧ�ܷ���false
		if(count!=0) {
			//���ҰѲ����˺�,�����Ѿ�����
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("patid",patid);
			map.put("staid", staff.getStaid());
			count=registrationService.updBreakByPatid(map);
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("showRecord")
	public String showUserBed(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String patname,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Staff staff=(Staff) session.getAttribute("staff");
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("staid",staff.getStaid());
		map.put("patname",StringUtil.formatLike(patname));
		List<Record> list = recordService.showRecordList(map);
		session.setAttribute("recordList",list);
		Integer total=recordService.getRecordTotal(staff.getStaid());
		
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(list,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateRecord")
	public String updateRecord(Record record,HttpServletResponse resp) throws Exception {
		Integer count=0;
		count=recordService.updateRecord(record);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
}
