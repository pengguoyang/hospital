package com.hospital.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Drug;
import com.hospital.entity.DrugDTO;
import com.hospital.entity.Prescription;
import com.hospital.entity.PrescriptionDTO;
import com.hospital.entity.Prescriptiondetail;
import com.hospital.entity.Stock;
import com.hospital.entity.StockDTO;
import com.hospital.service.DrugService;
import com.hospital.service.PrescriptionService;
import com.hospital.service.PrescriptiondetailService;
import com.hospital.service.StockService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("drug")
public class DrugController {
	@Resource
	private DrugService drugService;
	@Resource
	private StockService stockService;
	@Resource
	private PrescriptionService prescriptionService;
	@Resource
	private PrescriptiondetailService prescriptiondetailService;
	@RequestMapping("addDrug")
	public String addDrug(Drug drug,Stock stock,HttpServletResponse resp) throws Exception {
		int count1=0;
		int count2=0;
		count1=drugService.addDrug(drug);
		stock.setDrug(drug);
		stock.setDrugnum(stock.getStosavenum());
		stock.setStoinputtime(new Date());
		count2=stockService.addStock(stock);
		JSONObject result=new JSONObject();
		if(count1+count2>=2) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("showDrug")
	public String showDrug(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String drugname,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("drugname",StringUtil.formatLike(drugname));
		List<Drug> drugList = drugService.showDrugList(map);
		List<DrugDTO> drugDTOList=new ArrayList<DrugDTO>();
		for (Drug drug : drugList) {
			int drugnum=drugService.getSumByDrugName(drug.getDrugname());
			DrugDTO drugDTO = new DrugDTO(drug.getDrugid(), drug.getDrugname(), drug.getDrugbrand(),drug.getDrugnote(),drug.getDrugtype(),drug.getDrugpay(), drugnum);
			drugDTOList.add(drugDTO);
		}
		Integer total = drugService.getDrugTotal(map);
		JSONObject result=new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(drugDTOList);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateDrugInit")
	public String updateDrugInit(Integer drugid,HttpServletResponse resp) throws Exception {
		Drug drugById = drugService.getDrugById(drugid);
		JSONObject result=new JSONObject();
		if(drugById!=null) {
			result.put("success", Boolean.valueOf(true));
			result.put("drugname",drugById.getDrugname());
			result.put("drugnote",drugById.getDrugnote());
			result.put("drugtype",drugById.getDrugtype());
			result.put("drugpay",drugById.getDrugpay());
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateDrug")
	public String updateDrug(Drug drug,HttpServletResponse resp) throws Exception {
		int count=0;
		Drug drugByName = drugService.getDrugByName(drug.getDrugname());
		drug.setDrugid(drugByName.getDrugid());
		count=drugService.updateDrug(drug);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("showStock")
	public String showStock(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String drugname,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("drugname",StringUtil.formatLike(drugname));
		List<Stock> stockList = stockService.showAllStockList(map);
		Integer total = stockService.getStockTotal();
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(stockList,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("addStock")
	public String addStock(Stock stock,HttpServletResponse resp) throws Exception {
		int count=0;
		String drugname = stock.getDrug().getDrugname();
		Drug drugByName = drugService.getDrugByName(drugname);
		stock.setDrug(drugByName);
		stock.setStosavenum(stock.getDrugnum());
		stock.setStoinputtime(new Date());
		count=stockService.addStock(stock);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("deleteStock")
	public String deleteStock(@RequestParam("stoids")String stoids,HttpServletResponse resp) throws Exception {
		int count=0;
		String[] stoidsStr=stoids.split(",");
		for(int i=0;i<stoidsStr.length;i++) {
			count=stockService.deleteStock(Integer.parseInt(stoidsStr[i]));
		}
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateStock")
	public String updateStock(Stock stock,HttpServletResponse resp) throws Exception {
		int count=0;
		//得到stoid获得原先的库存信息
		Integer stoid=stock.getStoid();
		Stock stockById = stockService.getStockById(stoid);
		//计算出数量的差，比原先少则poor大于0，否则小于0
		Integer poor=stockById.getStosavenum()-stock.getStosavenum();
		Integer newDrugNum=stockById.getDrugnum()-poor;
		String drugname = stock.getDrug().getDrugname();
		Drug drugByName = drugService.getDrugByName(drugname);
		stock.setDrug(drugByName);
		stock.setDrugnum(newDrugNum);
		stock.setStoinputtime(new Date());
		count=stockService.updateStock(stock);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("showPrescriptionDTO")
	public String takeDrug(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String patcard,Boolean isOutDate,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("patcard",patcard);
		if(isOutDate!=null&&isOutDate==true) {
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			map.put("predate",sf.format(new Date()));
		}
		List<Prescription>  prescriptionList= prescriptionService.showPrescriptionList(map);
		List<PrescriptionDTO> prescriptionDTOList=new ArrayList<PrescriptionDTO>();
		for (Prescription prescription : prescriptionList) {
			int preid=prescription.getPreid();
			Date predate=prescription.getPredate();
			String patname=prescription.getRecord().getPatient().getPatname();
			List<Prescriptiondetail> prescriptiondetailList = prescriptiondetailService.getPrescriptiondetailByPreid(preid);
			//将药品名字和数量转换成字符串。
			StringBuffer sb=new StringBuffer();
			//计算一个处方对应的处方详情价格总和
			Integer price=0;
			for (Prescriptiondetail pres : prescriptiondetailList) {
				sb.append(pres.getDrug().getDrugname());
				sb.append(":");
				sb.append(pres.getDrugnumber());
				sb.append(",");
				price+=pres.getDetprice();
			}
			sb.setCharAt(sb.length()-1,'。');
			String drugStr=sb.toString();
			PrescriptionDTO prescriptionDTO = new PrescriptionDTO(preid, patname, predate, drugStr, price);
			prescriptionDTOList.add(prescriptionDTO);
		}
		Integer total= prescriptionService.PrescriptionTotal();
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(prescriptionDTOList,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("takeDrug")
	public String takeDrug(Integer preid,HttpServletResponse resp) throws Exception {
		Integer count=0;
		count= prescriptionService.updateToget(preid);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
}
