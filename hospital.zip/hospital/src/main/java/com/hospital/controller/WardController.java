package com.hospital.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Bed;
import com.hospital.entity.Ward;
import com.hospital.entity.WardDTO;
import com.hospital.service.BedService;
import com.hospital.service.WardService;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("ward")
public class WardController {
	@Resource
	private WardService wardService;
	@Resource
	private BedService bedService;
	@RequestMapping("showWard")
	public String showWard(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String wardtype,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("wardtype",StringUtil.formatLike(wardtype));
		List<Ward> showWardList = wardService.showWardList(map);
		List<WardDTO> wardDTOList=new ArrayList<WardDTO>();
		for (Ward ward : showWardList) {
			int usernumber= bedService.getNumberByWardid(ward.getWardid());
			WardDTO wardDTO = new WardDTO(ward.getWardid(), ward.getWardtype(),ward.getWardprice(),ward.getDepartment(), usernumber);
			wardDTOList.add(wardDTO);
		}
		Integer total=wardService.getWardTotal();
		JSONObject result=new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(wardDTOList);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("addWard")
	public String addWard(WardDTO wardDTO,Integer bednumber,HttpServletResponse resp) throws Exception {
		int count=0;
		Ward ward = new Ward(null, wardDTO.getWardtype(), wardDTO.getWardprice(), wardDTO.getDepartment());
		count=wardService.addWard(ward);
		//�õ��ò����Ĳ�������
		int bednum=wardDTO.getUsernumber();
		for (int i = 0; i < bednum; i++) {
			Bed bed = new Bed(null, ward,bednumber+i, null,null,true);
			count= bedService.addBed(bed);
		}
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
}
