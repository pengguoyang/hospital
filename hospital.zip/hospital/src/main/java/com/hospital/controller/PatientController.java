package com.hospital.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Patient;
import com.hospital.entity.Registration;
import com.hospital.entity.Staff;
import com.hospital.service.PatientService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.DateUtil;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("Patient")
public class PatientController {
	@Resource
	private PatientService  patientService;
	@RequestMapping("showPatient")
	public List<Patient> showPatientList(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,Patient patient,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("patname",StringUtil.formatLike(patient.getPatname()));
		List<Patient> showPatientList = patientService.showPatientList(map);
		Integer patientTotal = patientService.patientTotal();
		//��װ��json
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray array=JSONArray.fromObject(showPatientList,config);
		result.put("rows", array);
		result.put("total", patientTotal);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("updateInit")
	public String updateInit(int patid,HttpServletResponse resp) throws Exception {
		Patient patientById = patientService.getPatientById(patid);
		JSONObject result=new JSONObject();
		if(patientById!=null) {
			result.put("patname",patientById.getPatname());
			//ת�����ڸ�ʽΪ�ַ���
			String patbirth=DateUtil.formatDate(patientById.getPatbirth(), "yyyy-MM-dd");
			result.put("patbirth",patbirth);
			result.put("patsex", patientById.getPatsex());
			result.put("patage", patientById.getPatage());
			result.put("patphone", patientById.getPatphone());
			result.put("patcard", patientById.getPatcard());
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("updatePatient")
	public String updatePatient(Patient patient,HttpServletResponse resp) throws Exception {
		int count=0;
		count = patientService.updatePatient(patient);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("showRegistrationPatient")
	public List<Patient> showRegistrationPatientList(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,Patient patient,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		Staff staff = (Staff) req.getSession().getAttribute("staff");
		Integer staid=staff.getStaid();
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("staid",staid);
		map.put("patname",StringUtil.formatLike(patient.getPatname()));
		List<Patient> showRegistrationPatientList = patientService.showRegistrationPatientList(map);
		Integer registrationPatientTotal = patientService.registrationPatientTotal(staid);
		//��װ��json
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray array=JSONArray.fromObject(showRegistrationPatientList,config);
		result.put("rows", array);
		result.put("total",registrationPatientTotal);
		ResponseUtil.write(resp, result);
		return null;
	}
}
