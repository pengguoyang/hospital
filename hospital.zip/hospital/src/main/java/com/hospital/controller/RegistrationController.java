package com.hospital.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Department;
import com.hospital.entity.Patient;
import com.hospital.entity.Registration;
import com.hospital.entity.Staff;
import com.hospital.service.DepartmentService;
import com.hospital.service.PatientService;
import com.hospital.service.RegistrationService;
import com.hospital.service.StaffService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("Registration")
public class RegistrationController {
	@Resource
	private PatientService patientService;
	@Resource
	private RegistrationService registrationService;
	@Resource
	private DepartmentService departmentService;
	@Resource
	private StaffService staffService;
	
	@RequestMapping("addRegistration")
	public String addRegistration(Patient patient,Integer depid,HttpServletRequest req,HttpServletResponse resp) throws Exception {
		//����һ����־����¼�������޸Ĳ����Ƿ�ɹ�
		int count=0;
		HttpSession session = req.getSession();
		//ͨ��������������֤�Ų�ѯ����
		String patcard = patient.getPatcard();
		Patient patientByCard = patientService.getPatientByCard(patcard);
		if(patientByCard!=null) {
			//�õ����ݿ��и���Ϣ��id,������ǰ�˽��洫�����Ķ�����������ʵ���޸�
			Integer patid = patientByCard.getPatid();
			patient.setPatid(patid);
			count= patientService.updatePatient(patient);
		}else {
			//���ݿ�û�иò��˼�¼������
			count=patientService.addPatient(patient);
		}
		//ִ�������в������ж��Ƿ�ɹ�ִ��ȫ����������Ϣ
		JSONObject result=new JSONObject();
		if(count>0) {
			//�Ѳ��˷Ž�session��
			Patient patientBycard = patientService.getPatientByCard(patcard);
			session.setAttribute("patient", patientBycard);
			//�Ѵ����������Ŀ���id�Ž�session
			session.setAttribute("Depid", depid);
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("registration")
	public String registration(Integer staid,HttpServletRequest req,HttpServletResponse resp) throws Exception{
		int count=0;
		HttpSession session = req.getSession();
		Integer Depid = (Integer) session.getAttribute("Depid");
		Department departmentById = departmentService.getDepartmentById(Depid);
		Patient patient= (Patient) session.getAttribute("patient");
		Staff staffById = staffService.getStaffById(staid);
		Registration registration = new Registration(null, departmentById, new Date(), false, patient,staffById);
		count = registrationService.addRegistration(registration);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("showRegistration")
	public List<Registration> showRegistration(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String patname,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("patname",StringUtil.formatLike(patname));
		List<Registration> registrationList = registrationService.showRegistrationList(map);
		Integer total = registrationService.registrationTotal();
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(registrationList,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("break")
	public String Break(int regid,HttpServletResponse resp) throws Exception {
		Integer count= registrationService.updBreak(regid);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("breakByPatid")
	public String BreakByPatid(int patid,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		HttpSession session = req.getSession();
		Staff staff = (Staff) session.getAttribute("staff");
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("patid", patid);
		map.put("staid", staff.getStaid());
		Integer count = registrationService.updBreakByPatid(map);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("updateInit")
	public String updateInit(int regid,HttpServletRequest req, HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Registration registrationByRegid = registrationService.getRegistrationByRegid(regid);
		Integer depid = registrationByRegid.getDepartment().getDepid();
		Map<String,Object> map=new HashMap<String, Object>();
		map.put("depid", depid);
		List<Staff> updDoctorList = staffService.showDoctorByDepid(map);
		JSONObject result=new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(updDoctorList); 
		if(updDoctorList!=null) {
			result.put("rows", jsonArray);
			result.put("patname", registrationByRegid.getPatient().getPatname());
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateInfo")
	public String updateInfo(Registration registration,String patname,HttpServletResponse resp) throws Exception {
		int count=0;
		//���ݴ�����id�õ�����ԭ���ĹҺ���Ϣ
		Registration registrationByRegid = registrationService.getRegistrationByRegid(registration.getRegid());
		//�޸ĸùҺ���Ϣ��Ӧ�Ĳ�������
		Patient patient = registrationByRegid.getPatient();
		patient.setPatname(patname);
		count= patientService.updatePatient(patient);
		if(count>0) {
			//�޸ĹҺű���ҽ��id
			count = registrationService.updateRegistration(registration);
		}
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
}
