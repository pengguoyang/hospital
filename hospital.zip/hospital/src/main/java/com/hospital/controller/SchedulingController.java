package com.hospital.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hospital.entity.Department;
import com.hospital.entity.Scheduling;
import com.hospital.entity.Staff;
import com.hospital.entity.StaffScheduling;
import com.hospital.service.DepartmentService;
import com.hospital.service.SchedulingService;
import com.hospital.service.StaffService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.ListUtil;
import com.hospital.util.ResponseUtil;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("scheduling")
public class SchedulingController {
	@Resource
	private DepartmentService departmentService;
	@Resource
	private StaffService staffService;
	@Resource
	private SchedulingService schedulingService;
	
	@RequestMapping("selScheduling")
	public String selScheduling(String dId,int roleid,HttpServletResponse resp) throws Exception {
		Department depById = departmentService.getDepartmentById(Integer.parseInt(dId));
		System.out.println(depById);
		//��ȡ�ÿ��Ҷ�Ӧ��ҽ����Ϣ
		int depid=Integer.parseInt(dId);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("depid", depid);
		map.put("roleid", roleid);
		List<Staff> staffByDepid = staffService.getStaffByDepid(map);
		//����һ��������б����StaffScheduling
		List<StaffScheduling> list = new ArrayList<StaffScheduling>();
		if(depById==null) {
			return null;
		}
		//�����ÿ��Ҷ�Ӧ������Ա����Ϣ
		//ͨ��service��ѯÿ��Ա��ӵ�е��Ű��б���List<Scheduling>
		//�ٱ������б�����ÿ���Ű��б���ת����StaffScheduling����
		for (Staff staff: staffByDepid) {
			List<Scheduling> schedulingByStaid = schedulingService.getSchedulingByStaid(staff.getStaid());
			for (Scheduling sch : schedulingByStaid) {
				String str=sch.getSchtime()+""+sch.getSchweek();
				StaffScheduling staffScheduling=new StaffScheduling();
				staffScheduling.setSchedulingList(schedulingByStaid);
				staffScheduling.setStaid(staff.getStaid());
				staffScheduling.setStaname(staff.getStaname());
				staffScheduling.setTemp(str);
				list.add(staffScheduling);
			}
		}
		//��װ��json
		JSONObject result=new JSONObject();
		JSONArray array=JSONArray.fromObject(list);
		result.put("rows", array);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("findstaffByday")
	public String findstaffByday(String depid,int roleid,@RequestParam("staids")String staids,HttpServletResponse resp) throws Exception {
		String[] staidStr=staids.split(",");
		//����һ������ֵ���ҽ��id�б�
		List<String> staidList=new ArrayList<String>();
		for (String staidstr : staidStr) {
			staidList.add(staidstr);
		}
		//��ȡ�ÿ��Ҷ�Ӧ��ҽ����Ϣ
		int did=Integer.parseInt(depid);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("depid", did);
		map.put("roleid", roleid);
		List<Staff> staffByDepid = staffService.getStaffByDepid(map);
		//����һ������ҽ��id�б�
		List<String> allStaidList=new ArrayList<String>();
		for (Staff staff : staffByDepid) {
			allStaidList.add(staff.getStaid().toString());
		}
		//�õ����ʱ��ο��е�ҽ��
		List<String> userStaidList=ListUtil.getdifferentList(allStaidList, staidList);
		List<Staff> userStaffList=new ArrayList<Staff>();
		for (String staidstr : userStaidList) {
			Staff staffById = staffService.getStaffById(Integer.parseInt(staidstr));
			userStaffList.add(staffById);
		}
		//��װ��json
		JSONObject result=new JSONObject();
		JSONArray array=JSONArray.fromObject(userStaffList);
		result.put("rows", array);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	
	@RequestMapping("insScheduling")
	public String insScheduling(String StaffSchList,int roleid,HttpServletResponse resp) throws Exception {
		String newStaffSchList=StaffSchList.substring(1,StaffSchList.length()-1);
		String[] staSchList=newStaffSchList.split("},");
		List<StaffScheduling> StaffSchedulingList=new ArrayList<StaffScheduling>();
		for (String string : staSchList) {
			string+="}";
			JSONObject s = JSONObject.fromObject(string);
			StaffScheduling staffScheduling=(StaffScheduling) JSONObject.toBean(s,StaffScheduling.class);
			StaffSchedulingList.add(staffScheduling);
		}
		StaffScheduling sta = StaffSchedulingList.get(0);
		if(sta!=null) {
			Integer staid = sta.getStaid();
			//�õ�Ա����Ӧ�Ŀ���id
			Integer depid=staffService.getStaffById(staid).getDepartment().getDepid();
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("depid", depid);
			map.put("roleid", roleid);
			//��������Ű���ļ�¼
			schedulingService.deleteBydepid(map);
		}
		for (StaffScheduling staffScheduling : StaffSchedulingList) {
			String temp = staffScheduling.getTemp();
			int schweek=Integer.parseInt(temp)%10;
			int schtime=Integer.parseInt(temp)/10;
			Staff staff=staffService.getStaffById(staffScheduling.getStaid());
			Scheduling scheduling = new Scheduling(null, schweek, schtime, staff);
			schedulingService.insertScheduling(scheduling);
		}
		JSONObject result=new JSONObject();
		result.put("success", Boolean.valueOf(true));
		ResponseUtil.write(resp, result);
		return null;
	}
}
