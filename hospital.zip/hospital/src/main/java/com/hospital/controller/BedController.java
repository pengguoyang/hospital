package com.hospital.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Bed;
import com.hospital.entity.Live;
import com.hospital.entity.Patient;
import com.hospital.entity.PatientDTO;
import com.hospital.entity.Staff;
import com.hospital.service.BedService;
import com.hospital.service.LiveService;
import com.hospital.service.PatientService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("bed")
public class BedController {
	@Resource
	private BedService bedService;
	@Resource
	private PatientService patientService;
	@Resource
	private LiveService liveService;
	@RequestMapping("showUserBed")
	public String showUserBed(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String wardtype,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Staff staff=(Staff) session.getAttribute("staff");
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("depid",staff.getDepartment().getDepid());
		map.put("wardtype",StringUtil.formatLike(wardtype));
		map.put("state",true);
		List<Bed> list = bedService.list(map);
		session.setAttribute("bedList",list);
		Integer total=bedService.BedTotal(staff.getDepartment().getDepid());
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(list,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("bedInit")
	public String bedInit(int patid,HttpServletRequest req,HttpServletResponse resp) throws Exception {
		//�������һ��������ص�session
		HttpSession session = req.getSession();
		session.removeAttribute("stockDTOList");
		session.removeAttribute("PrescriptiondetailDTOList");
		session.removeAttribute("pastdisease");
		session.removeAttribute("reccontent");
		Patient patientById = patientService.getPatientById(patid);
		JSONObject result=new JSONObject();
		if(patientById!=null) {
			session.setAttribute("patid", patientById.getPatid());
			session.setAttribute("patname", patientById.getPatname());
			session.setAttribute("patsex", patientById.getPatsex());
			session.setAttribute("patage", patientById.getPatage());
			//��ͨ��patid�жϸò����Ƿ��Ѿ�סԺ������ǣ��򷵻�false��ǰ��
			Live liveBypatId = liveService.getLiveBypatId(patid);
			if(liveBypatId!=null) {
				result.put("success", Boolean.valueOf(false));
			}else {
				result.put("success",Boolean.valueOf(true));
			}
		}else {
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("live")
	public String live(Integer bedid,String familyname,String familyphone,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		int count1=0;
		int count2=0;
		int count3=0;
		HttpSession session = req.getSession();
		JSONObject result=new JSONObject();
		Integer patid=(Integer) session.getAttribute("patid");
		Patient patient = patientService.getPatientById(patid);
		//���²�����Ϣ
		patient.setFamilyname(familyname);
		patient.setFamilyphone(familyphone);
		count3=patientService.updatePatient(patient);
		Bed bed = bedService.getBedById(bedid);
		bed.setPatient(patient);
		bed.setInputtime(new Date());
		bed.setState(false);
		count1=bedService.updateBed(bed);
		//��������һ��סԺ��Ϣ
		Live live=new Live(null, bed, patient, new Date(),null,null);
		count2 = liveService.addLive(live);
		if((count1+count2+count3)>=3) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("showLive")
	public String showLive(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String patname,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		Staff staff=(Staff) session.getAttribute("staff");
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> paramMap=new HashMap<String,Object>();
		paramMap.put("depid", staff.getDepartment().getDepid());
		paramMap.put("state",false);
		paramMap.put("start", pageBean.getStart());
		paramMap.put("size",pageBean.getPageSize());
		paramMap.put("patname",StringUtil.formatLike(patname));
		List<Bed> list = bedService.list(paramMap);
		//��ǰ����Ҫ��ʾ����Ϣͨ��DTO����а�װ
		List<PatientDTO> patientDTOList=new ArrayList<PatientDTO>();
		for (Bed bed : list) {
			Patient patient=bed.getPatient();
			PatientDTO patientDTO = new PatientDTO(bed.getWard().getWardid(),bed.getBedid(), bed.getBednumber(), patient.getPatid(),
			patient.getPatname(),patient.getPatsex(),patient.getPatage(), 
			bed.getInputtime(),patient.getPatphone(),patient.getFamilyname(),patient.getFamilyphone());
			patientDTOList.add(patientDTO);
		}
		session.setAttribute("patientDTOList",patientDTOList);
		Integer total=bedService.userBedTotal(staff.getDepartment().getDepid());
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(patientDTOList,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateBedInit")
	public String updateBedInit(Integer patid,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		HttpSession session = req.getSession();
		//�õ���������
		Bed bed = bedService.getBedByPatId(patid);
		JSONObject result=new JSONObject();
		if(bed!=null) {
			//�õ����˶���
			Patient patient=bed.getPatient();
			PatientDTO patientDTO = new PatientDTO(bed.getWard().getWardid(),bed.getBedid(), bed.getBednumber(), patient.getPatid(),
					patient.getPatname(),patient.getPatsex(),patient.getPatage(), 
					bed.getInputtime(),patient.getPatphone(),patient.getFamilyname(),patient.getFamilyphone());
			session.setAttribute("patientDTO",patientDTO);
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updatebed")
	public String updatebed(Integer newbedid,HttpServletRequest req,HttpServletResponse resp) throws Exception {
		int count1=0;
		int count2=0;
		int count3=0;
		int count4=0;
		//�õ�Ҫ�����Ĳ�������
		Bed newbed = bedService.getBedById(newbedid);
		//�õ�session�е�patientDTO���󣬱�ʾ��ǰ�����Ĳ����Լ������Ϣ
		HttpSession session = req.getSession();
		PatientDTO patientDTO = (PatientDTO) session.getAttribute("patientDTO");
		//�õ������Ĳ�������,�Լ��õ����˶���
		Bed oldbed= bedService.getBedByPatId(patientDTO.getPatid());
		Patient patient=oldbed.getPatient();
		//���ݲ���id���δ�����סԺ��¼,������н��崦��
		Live live = liveService.getLiveBypatId(patientDTO.getPatid());
		live.setOuttime(new Date());
		//����סԺ��¼סԺ����������������סԺ��
		Date inputDate=live.getInputtime();
		Date outDate=live.getOuttime();
		long liveSeconds = outDate.getTime() - inputDate.getTime();
		long liveDay =liveSeconds / (1000 * 3600)/ 24;
		//������ס��������һ��
		if(liveDay==0L) {
			liveDay=1L;
		}
		Integer money=(int)liveDay*oldbed.getWard().getWardprice();
		live.setPay(money);
		//����סԺ��¼
		count1= liveService.updateLive(live);
		//��վɲ�������Ϣ
		count2=bedService.updateBedSetNull(oldbed.getBedid());
		//����ס�Ĳ���
		newbed.setInputtime(new Date());
		newbed.setPatient(patient);
		newbed.setState(false);
		count3=bedService.updateBed(newbed);
		//����һ��סԺ��¼
		Live newLive=new Live(null, newbed, patient, new Date(),null,null);
		count4 = liveService.addLive(newLive);
		session.removeAttribute("patientDTO");
		JSONObject result=new JSONObject();
		if(count1+count2+count3+count4>=4) {
			result.put("pay", money);
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("breakLive")
	public String breakLive(Integer patid,HttpServletResponse resp) throws Exception {
		int count1=0;
		int count2=0;
		//�õ���������
		Bed bed = bedService.getBedByPatId(patid);
		//���ݲ���id���δ�����סԺ��¼,������н��崦��
		Live live = liveService.getLiveBypatId(patid);
		live.setOuttime(new Date());
		//����סԺ��¼סԺ����������������סԺ��
		Date inputDate=live.getInputtime();
		Date outDate=live.getOuttime();
		long liveSeconds = outDate.getTime() - inputDate.getTime();
		long liveDay =liveSeconds / (1000 * 3600)/ 24;
		//������ס��������һ��
		if(liveDay==0L) {
			liveDay=1L;
		}
		Integer money=(int)liveDay*bed.getWard().getWardprice();
		live.setPay(money);
		//����סԺ��¼
		count1= liveService.updateLive(live);
		//��վɲ�������Ϣ
		count2=bedService.updateBedSetNull(bed.getBedid());
		JSONObject result=new JSONObject();
		if(count1+count2>=2) {
			result.put("pay", money);
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
}
