package com.hospital.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Department;
import com.hospital.entity.Patient;
import com.hospital.entity.Staff;
import com.hospital.service.DepartmentService;
import com.hospital.service.StaffService;
import com.hospital.util.CryptographyUtil;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("staff")
public class StaffController {
	@Resource
	private StaffService staffService;
	@Resource
	private DepartmentService departmentService;
	@RequestMapping("login")
	public String login(HttpServletRequest req,Staff staff) throws Exception {
		String staphone= staff.getStaphone();
		String password =staff.getPassword();
		String pw = CryptographyUtil.md5(password, "hospital");
		/**Subject*/
		Subject subject = SecurityUtils.getSubject();
		UsernamePasswordToken token = new UsernamePasswordToken(staphone,pw);
		try {
			//����token��shiro��realm
			subject.login(token);
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("staphone", staphone);
			map.put("password", pw);
			Staff staffSession=staffService.login(map);
			List<Department> showDepartmentList = departmentService.showDepartmentList();
			req.getSession().setAttribute("departmentList", showDepartmentList );
			req.getSession().setAttribute("staff",staffSession);
			return "redirect:/admin/main.jsp";
		}catch(Exception e) {
			e.printStackTrace();
			//�����û���Ϣ������jspҳ��Ͳ������������û���Ϣ
			req.setAttribute("staphone",staphone);
			req.setAttribute("password",password);
			req.setAttribute("erroInfo", "�û������������");
		}
		
		return "login";
	}
	@RequestMapping("showDoctor")
	public List<Staff> showDoctorPage(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,Staff staff,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		HttpSession session = req.getSession();
		Integer Depid = (Integer) session.getAttribute("Depid");
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("depid",Depid);
		map.put("staname", StringUtil.formatLike(staff.getStaname()));
		List<Staff> doctorListByDepid = staffService.showDoctorByDepid(map);
		Integer total = staffService.doctorByDepidTotal(Depid);
		//��װ��json
		JSONObject result = new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(doctorListByDepid);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("modifyInfo")
	public String modifyInfo(Staff staff,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		Integer count=0;
		HttpSession session = req.getSession();
		Staff sta= (Staff) session.getAttribute("staff");
		Integer staid=sta.getStaid();
		staff.setStaid(staid);
		count = staffService.updateInfo(staff);
		//�޸������session
		Staff staffById = staffService.getStaffById(staid);
		session.setAttribute("staff", staffById);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("staname",staff.getStaname());
			result.put("staphone",staff.getStaphone());
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp,result);
		return null;
	}
	@RequestMapping("modifyPassword")
	public String modifyPassword(String oldPassword,String newPassword,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		Integer count=0;
		HttpSession session = req.getSession();
		Staff staff = (Staff) session.getAttribute("staff");
		JSONObject result=new JSONObject();
		if(CryptographyUtil.md5(oldPassword,"hospital").equals(staff.getPassword())) {
			staff.setPassword(CryptographyUtil.md5(newPassword,"hospital"));
			count = staffService.updateInfo(staff);
			if(count!=0) {
				result.put("success",Boolean.valueOf(true));
				Staff newStaff = staffService.getStaffById(staff.getStaid());
				newStaff.setPassword(newPassword);
				session.setAttribute("staff",newStaff);
			}else {
				result.put("success",Boolean.valueOf(false));
			}
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp,result);
		return null;
	}
	
	@RequestMapping("showStaff")
	public List<Patient> showStaff(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String staname,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("staname",StringUtil.formatLike(staname));
		List<Staff> showAllStaff = staffService.showAllStaff(map);
		Integer staffTotal = staffService.StaffTotal();
		//��װ��json
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray array=JSONArray.fromObject(showAllStaff,config);
		result.put("rows", array);
		result.put("total", staffTotal);
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("addStaff")
	public String addStaff(Staff staff,HttpServletResponse resp) throws Exception {
		int count=0;
		//����Ĭ������Ϊ123
		String password=CryptographyUtil.md5("123","hospital");
		staff.setPassword(password);
		staff.setStaentrydate(new Date());
		staff.setIsincumbency(true);
		count=staffService.addStaff(staff);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp,result);
		return null;
	}
	@RequestMapping("deleteStaff")
	public String deleteStaff(Integer staid,HttpServletResponse resp) throws Exception {
		int count=0;
		Staff staff= staffService.getStaffById(staid);
		staff.setIsincumbency(false);
		count=staffService.updateInfo(staff);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp,result);
		return null;
	}
	
	@RequestMapping("out")
	public String out() {
		SecurityUtils.getSubject().logout();
		return "redirect:/login.jsp";
	}
}
