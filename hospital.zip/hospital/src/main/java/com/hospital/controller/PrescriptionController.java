package com.hospital.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Drug;
import com.hospital.entity.Prescriptiondetail;
import com.hospital.entity.Stock;
import com.hospital.entity.StockDTO;
import com.hospital.service.DrugService;
import com.hospital.service.PrescriptionService;
import com.hospital.service.PrescriptiondetailService;
import com.hospital.service.StockService;
import com.hospital.util.DateJsonValueProcessor;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;
import com.hospital.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

@Controller
@RequestMapping("prescription")
public class PrescriptionController {
	@Resource
	private StockService stockService;
	@Resource
	private DrugService drugService;
	@Resource
	private PrescriptionService prescriptionService;
	@Resource
	private PrescriptiondetailService prescriptiondetailService;
	
	@RequestMapping("showStock")
	public String showStock(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,String drugname,HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		map.put("drugname",StringUtil.formatLike(drugname));
		List<Stock> stockList = stockService.showStockList(map);
		session.setAttribute("stockList", stockList);
		List<StockDTO> stockDTOList=new ArrayList<StockDTO>();
		for (Stock stock: stockList) {
			StockDTO s=new StockDTO(stock.getStoid(), stock.getDrug().getDrugname(),stock.getDrug().getDrugbrand() ,stock.getDrug().getDrugtype(),stock.getDrugnum(), stock.getDrug().getDrugpay(), stock.getDrug().getDrugnote());
			stockDTOList.add(s);
		}
		Integer total = stockService.getStockTotal();
		//��stockDTOList�Ľ�������session��
		List<StockDTO> StockDTOSessionList = (List<StockDTO>) session.getAttribute("stockDTOList");
		//���û��������session����ֵ��StockDTOSessionList
		if(StockDTOSessionList==null) {
			session.setAttribute("stockDTOList", stockDTOList);
			StockDTOSessionList=stockDTOList;
		}
		JSONObject result=new JSONObject();
		JsonConfig config = new JsonConfig();
		config.registerJsonValueProcessor(Date.class, new DateJsonValueProcessor("yyyy-MM-dd"));
		JSONArray jsonArray = JSONArray.fromObject(StockDTOSessionList,config);
		result.put("rows", jsonArray);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("addDrug")
	public String addDrug(String drugname,Integer stoid,Integer drugnum,HttpServletResponse resp,HttpServletRequest req) throws Exception {
		//����һ����־λ����¼�����б����Ƿ��к�stoid��ȵ�ֵ
		int flag=0;
		HttpSession session = req.getSession();
		List<StockDTO> StockDTOSessionList= (List<StockDTO>) session.getAttribute("stockDTOList");
		for (StockDTO stockDTO : StockDTOSessionList) {
			//��������ҩƷ����������������ȥ���������
			if(stoid.equals(stockDTO.getStoid())) {
				stockDTO.setDrugnum(stockDTO.getDrugnum()-drugnum);
			}
		}
		List<Prescriptiondetail> PrescriptiondetailList=(List<Prescriptiondetail>)session.getAttribute("PrescriptiondetailList");
		if(PrescriptiondetailList==null) {
			//����һ������������б������������ʱ������
			List<Prescriptiondetail> Prescriptiondetaillist=new ArrayList<Prescriptiondetail>();
			PrescriptiondetailList=Prescriptiondetaillist;
		}
		//������id��ͬ�������µļ�¼,�����ͬ�����ҩƷ����
		if(PrescriptiondetailList!=null) {
			for (Prescriptiondetail prescriptiondetail : PrescriptiondetailList) {
				if(prescriptiondetail.getStock().getStoid()==stoid) {
					Drug drugByName = drugService.getDrugByName(drugname);
					Integer num=prescriptiondetail.getDrugnumber();
					prescriptiondetail.setDrugnumber(num+drugnum);
					prescriptiondetail.setDetprice((num+drugnum)*drugByName.getDrugpay());
					flag=1;
					break;
				}
			}
		}
		//���û�н����޸������������б�
		if(flag==0) {
			Drug drugByName = drugService.getDrugByName(drugname);
			Prescriptiondetail prescription=new Prescriptiondetail(null,stockService.getStockById(stoid), drugByName, drugnum, null,drugByName.getDrugpay()*drugnum);
			PrescriptiondetailList.add(prescription);
		}
		session.setAttribute("stockDTOList", StockDTOSessionList);
		session.setAttribute("PrescriptiondetailList",PrescriptiondetailList);
		JSONObject result=new JSONObject();
		result.put("success",Boolean.valueOf(true));
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("showPrescription")
	public String showPrescription(HttpServletRequest req,HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		List<Prescriptiondetail> PrescriptiondetailList=(List<Prescriptiondetail>)session.getAttribute("PrescriptiondetailList");
		JSONObject result=new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(PrescriptiondetailList);
		result.put("rows", jsonArray);
		result.put("total", PrescriptiondetailList.size());
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("deleteInfo")
	public String deletePrescription(Prescriptiondetail pre,HttpServletRequest req,HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		List<Prescriptiondetail> PrescriptiondetailList=(List<Prescriptiondetail>)session.getAttribute("PrescriptiondetailList");
		List<StockDTO> stockDTOList=(List<StockDTO>) session.getAttribute("stockDTOList");
		//���������б���������id��ȵĻ���ɾ��������¼
		for (Prescriptiondetail pres : PrescriptiondetailList) {
			if(pres.getStock().getStoid()==pre.getStock().getStoid()) {
				PrescriptiondetailList.remove(pres);
				break;
			}
		}
		//��������б���������id��ȣ�����������
		for (StockDTO stockDTO : stockDTOList) {
			if(stockDTO.getStoid()==pre.getStock().getStoid()) {
				Integer drugnum = stockDTO.getDrugnum();
				stockDTO.setDrugnum(drugnum+pre.getDrugnumber());
			}
		}
		JSONObject result=new JSONObject();
		result.put("success",Boolean.valueOf(true));
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("updateInfo")
	public String updateInfo(HttpServletRequest req,HttpServletResponse resp,Integer stoid,Integer drugnum) throws Exception {
		HttpSession session = req.getSession();
		List<Prescriptiondetail> PrescriptiondetailList=(List<Prescriptiondetail>)session.getAttribute("PrescriptiondetailList");
		List<StockDTO> stockDTOList=(List<StockDTO>) session.getAttribute("stockDTOList");
		//����һ����������ʾԭ������ҩƷ������ȥ�޸ĺ��������Ĭ��Ϊ0
		Integer poor=0;
		//���������б���������id��ȵĻ����޸Ķ�Ӧ����
		for (Prescriptiondetail pres : PrescriptiondetailList) {
			if(pres.getStock().getStoid()==stoid) {
				poor=pres.getDrugnumber()-drugnum;
				pres.setDrugnumber(drugnum);
				Stock stockById = stockService.getStockById(stoid);
				pres.setDetprice((drugnum)*stockById.getDrug().getDrugpay());
				break;
			}
		}
		//��������б���������id��ȣ�����������
		for (StockDTO stockDTO : stockDTOList) {
			if(stockDTO.getStoid()==stoid) {
				Integer n = stockDTO.getDrugnum();
				stockDTO.setDrugnum(n+poor);
			}
		}
		JSONObject result=new JSONObject();
		result.put("success",Boolean.valueOf(true));
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("Submission")
	public String Submission(HttpServletRequest req,HttpServletResponse resp) throws Exception {
		HttpSession session = req.getSession();
		List<Prescriptiondetail> PrescriptiondetailList=(List<Prescriptiondetail>)session.getAttribute("PrescriptiondetailList");
		StringBuffer sb=new StringBuffer();
		for (Prescriptiondetail pres : PrescriptiondetailList) {
			sb.append(pres.getDrug().getDrugname());
			sb.append(":");
			sb.append(pres.getDrugnumber());
			sb.append(",");
		}
		sb.setCharAt(sb.length()-1,'��');
		session.setAttribute("PrescriptionStr", sb);
		JSONObject result=new JSONObject();
		result.put("success",Boolean.valueOf(true));
		ResponseUtil.write(resp, result);
		return null;
	}
	
	@RequestMapping("deletePrescription")
	public String deletePrescription(@RequestParam("preids")String preids,HttpServletResponse resp) throws Exception {
		int count=0;
		String[] preidsStr=preids.split(",");
		for(int i=0;i<preidsStr.length;i++) {
			Integer preid=Integer.parseInt(preidsStr[i]);
			//�õ���Ӧ���д������飬���Ѷ�Ӧ��ҩƷ�ӻ�ȥ
			List<Prescriptiondetail> prescriptiondetailByPreid = prescriptiondetailService.getPrescriptiondetailByPreid(preid);
			for (Prescriptiondetail pre: prescriptiondetailByPreid) {
				Integer drugnumber = pre.getDrugnumber();
				//�õ����������ҩƷ���id������һ�б�ʾҩƷ��棩��Ȼ��Ѷ�Ӧ���������ӻ�ȥ��
				Integer stoid = pre.getStock().getStoid();
				Stock stockById = stockService.getStockById(stoid);
				//�õ���ǰҩƷ����
				Integer drugnum = stockById.getDrugnum();
				stockById.setDrugnum(drugnum+drugnumber);
				count=stockService.updateStock(stockById);
			}
			prescriptiondetailService.deleteByPreId(preid);
			prescriptionService.deleteByPreId(preid);
		}
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success", Boolean.valueOf(true));
		}else {
			result.put("success", Boolean.valueOf(false));
		}
		ResponseUtil.write(resp, result);
		return null;
	}
}
