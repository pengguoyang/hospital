package com.hospital.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.entity.Role;
import com.hospital.service.RoleService;
import com.hospital.util.PageBean;
import com.hospital.util.ResponseUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("role")
public class RoleController {
	@Resource
	private RoleService roleService;
	@RequestMapping("showRole")
	public String showRole(@RequestParam(value="page",required=false)String page,
			@RequestParam(value="rows",required=false)String rows,
			HttpServletResponse resp) throws Exception{
		PageBean pageBean = new PageBean(Integer.parseInt(page),Integer.parseInt(rows));
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("start", pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		List<Role> showRoleList = roleService.showRoleList(map);
		Integer total=roleService.RoleTotal();
		//json
		JSONObject result=new JSONObject();
		JSONArray array=JSONArray.fromObject(showRoleList);
		result.put("rows", array);
		result.put("total", total);
		ResponseUtil.write(resp, result);
		return null;
	}
	@RequestMapping("updateRole")
	public String updateRole(Role role,HttpServletResponse resp) throws Exception {
		int count=0;
		count= roleService.updateRole(role);
		JSONObject result=new JSONObject();
		if(count>0) {
			result.put("success",Boolean.valueOf(true));
		}else {
			result.put("success",Boolean.valueOf(false));
		}
		ResponseUtil.write(resp,result);
		return null;
	}
}
