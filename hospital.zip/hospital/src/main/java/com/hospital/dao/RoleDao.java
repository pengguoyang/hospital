package com.hospital.dao;


import java.util.List;
import java.util.Map;

import com.hospital.entity.Role;


public interface RoleDao {
	/**
	 * ͨ��id��ý�ɫ
	 * @param id
	 * @return
	 */
	public Role getRoleById(int id);
	/**
	 * ��ҳ��ʾְλ�б�
	 * @param map
	 * @return
	 */
	public List<Role> showRoleList(Map<String,Object> map);
	/**
	 * �õ�����ְλ��������
	 * @return
	 */
	public Integer RoleTotal();
	/**
	 * �޸�ְλ��Ϣ
	 * @param role
	 * @return
	 */
	public Integer updateRole(Role role);
	/**
	 * 根据id获得角色工资
	 * @param roleid
	 * @return
	 */
	public Integer getSalByRoleid(Integer roleid);
}
