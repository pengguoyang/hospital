package com.hospital.entity;

import lombok.Data;

@Data
public class Department {
    private Integer depid;

    private String depname;
    //���Ҽ��
    private String deppaper;
	public Department(Integer depid, String depname, String deppaper) {
		super();
		this.depid = depid;
		this.depname = depname;
		this.deppaper = deppaper;
	}
	public Department() {
		super();
	}
    
    
}