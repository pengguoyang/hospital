package com.hospital.entity;

import java.util.Date;

import lombok.Data;

@Data
public class PrescriptionDTO {
	private Integer preid;
	
	private String patname;

    private Date predate;
    /**
     * ��¼ҩƷ��Ӧ�������Լ�����
     */
    private String drugstr;
    /**
     *���� ҩƷ�ܼ۸�
     */
    private Integer price;
    
	public PrescriptionDTO(Integer preid, String patname, Date predate, String drugstr, Integer price) {
		super();
		this.preid = preid;
		this.patname = patname;
		this.predate = predate;
		this.drugstr = drugstr;
		this.price = price;
	}
	
	public PrescriptionDTO() {
		super();
	}
    
}
