package com.hospital.entity;

import lombok.Data;

@Data
public class WardDTO {
	private Integer wardid;

    private String wardtype;

    private Integer wardprice;

    private Department department;
    //�ò���ʣ����ò�����
    private Integer usernumber;
    
	public WardDTO(Integer wardid, String wardtype, Integer wardprice, Department department, Integer usernumber) {
		super();
		this.wardid = wardid;
		this.wardtype = wardtype;
		this.wardprice = wardprice;
		this.department = department;
		this.usernumber = usernumber;
	}

	public WardDTO() {
		super();
	}
    
    
}
