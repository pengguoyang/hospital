package com.hospital.entity;

import lombok.Data;

@Data
public class PrescriptiondetailDTO {
	private Integer detid;
	
	private Integer stoid;

    private Drug drug;

    private Integer drugnumber;

    private Prescription prescription;

    private Integer detprice;

	public PrescriptiondetailDTO(Integer detid, Integer stoid, Drug drug, Integer drugnumber, Prescription prescription,
			Integer detprice) {
		super();
		this.detid = detid;
		this.stoid = stoid;
		this.drug = drug;
		this.drugnumber = drugnumber;
		this.prescription = prescription;
		this.detprice = detprice;
	}

	public PrescriptiondetailDTO() {
		super();
	}
}
