package com.hospital.entity;

import lombok.Data;

@Data
public class Role {
    private Integer roleid;

    private String rolename;

    private Integer rolesal;

	public Role(Integer roleid, String rolename, Integer rolesal) {
		super();
		this.roleid = roleid;
		this.rolename = rolename;
		this.rolesal = rolesal;
	}

	public Role() {
		super();
	}

    
}