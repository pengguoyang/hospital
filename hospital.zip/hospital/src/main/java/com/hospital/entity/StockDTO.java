package com.hospital.entity;

import lombok.Data;

@Data
public class StockDTO {
	private Integer stoid;
	private String drugname;
	private String drugbrand;
	private String drugtype;
	private Integer drugnum;
	private Integer drugpay;
	private String drugnote;
	public StockDTO() {
		super();
	}
	public StockDTO(Integer stoid, String drugname, String drugbrand, String drugtype, Integer drugnum, Integer drugpay,
			String drugnote) {
		super();
		this.stoid = stoid;
		this.drugname = drugname;
		this.drugbrand = drugbrand;
		this.drugtype = drugtype;
		this.drugnum = drugnum;
		this.drugpay = drugpay;
		this.drugnote = drugnote;
	}
	
}
