package com.hospital.entity;

import lombok.Data;

@Data
public class RoleDTO {
	private Integer roleid;

    private String rolename;

    private Integer rolesal;

	private Integer salsum;

	public RoleDTO(Integer roleid, String rolename, Integer rolesal, Integer salsum) {
		super();
		this.roleid = roleid;
		this.rolename = rolename;
		this.rolesal = rolesal;
		this.salsum = salsum;
	}

	public RoleDTO() {
		super();
	}
	
}
