package com.hospital.entity;

import lombok.Data;

@Data
public class Prescriptiondetail {
    private Integer detid;
    
    private Stock stock;

    private Drug drug;

    private Integer drugnumber;

    private Prescription prescription;

    private Integer detprice;
    
	public Prescriptiondetail() {
		super();
	}

	public Prescriptiondetail(Integer detid, Stock stock, Drug drug, Integer drugnumber, Prescription prescription,
			Integer detprice) {
		super();
		this.detid = detid;
		this.stock=stock;
		this.drug = drug;
		this.drugnumber = drugnumber;
		this.prescription = prescription;
		this.detprice = detprice;
	}
    
    
    
}