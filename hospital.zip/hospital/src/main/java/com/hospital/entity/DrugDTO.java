package com.hospital.entity;

import lombok.Data;

@Data
public class DrugDTO {
	private Integer drugid;

    private String drugname;

    private String drugbrand;

    private String drugnote;

    private String drugtype;

    private Integer drugpay;
    
    private Integer drugnum;

	public DrugDTO(Integer drugid, String drugname, String drugbrand, String drugnote, String drugtype, Integer drugpay,
			Integer drugnum) {
		super();
		this.drugid = drugid;
		this.drugname = drugname;
		this.drugbrand = drugbrand;
		this.drugnote = drugnote;
		this.drugtype = drugtype;
		this.drugpay = drugpay;
		this.drugnum = drugnum;
	}

	public DrugDTO() {
		super();
	}
    
    
}
