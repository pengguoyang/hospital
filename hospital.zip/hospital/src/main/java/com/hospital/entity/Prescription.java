package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Prescription {
    private Integer preid;

    private Date predate;

    private Record record;

    private Boolean isget;

	public Prescription(Integer preid, Date predate, Record record, Boolean isget) {
		super();
		this.preid = preid;
		this.predate = predate;
		this.record = record;
		this.isget = isget;
	}

	public Prescription() {
		super();
	}

    
}