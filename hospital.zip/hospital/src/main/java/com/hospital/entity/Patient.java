package com.hospital.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
@Data
public class Patient {
    private Integer patid;

    private String patname;

    private Date patbirth;

    private String patsex;

    private Integer patage;

    private String patphone;

    private String patcard;

    private String familyname;

    private String familyphone;

	public Patient(Integer patid, String patname, Date patbirth, String patsex, Integer patage, String patphone,
			String patcard, String familyname, String familyphone) {
		super();
		this.patid = patid;
		this.patname = patname;
		this.patbirth = patbirth;
		this.patsex = patsex;
		this.patage = patage;
		this.patphone = patphone;
		this.patcard = patcard;
		this.familyname = familyname;
		this.familyphone = familyphone;
	}

	public Patient() {
		super();
	}
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date getPatbirth() {
		return patbirth;
	}
	public void setPatbirth(Date patbirth) {
		this.patbirth=patbirth;
	}
    
}