package com.hospital.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
@Data
public class Stock {
    private Integer stoid;

    private Drug drug;

    private Integer drugnum;

    private Date stoinputtime;

    private Date stouserdate;

    private Integer stoprice;

    private Integer stosavenum;

	public Stock(Integer stoid, Drug drug, Integer drugnum, Date stoinputtime, Date stouserdate, Integer stoprice,
			Integer stosavenum) {
		super();
		this.stoid = stoid;
		this.drug = drug;
		this.drugnum = drugnum;
		this.stoinputtime = stoinputtime;
		this.stouserdate = stouserdate;
		this.stoprice = stoprice;
		this.stosavenum = stosavenum;
	}

	public Stock() {
		super();
	}

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	public Date getStouserdate() {
		return stouserdate;
	}
	public void setStouserdate(Date stouserdate) {
		this.stouserdate=stouserdate;
	}
}