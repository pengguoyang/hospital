package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Record {
    private Integer recid;

    private String pastdisease;

    private String reccontent;

    private Staff staff;

    private Patient patient;

    private Date rectime;

	public Record(Integer recid, String pastdisease, String reccontent, Staff staff, Patient patient, Date rectime) {
		super();
		this.recid = recid;
		this.pastdisease = pastdisease;
		this.reccontent = reccontent;
		this.staff = staff;
		this.patient = patient;
		this.rectime = rectime;
	}

	public Record() {
		super();
	}

    
}