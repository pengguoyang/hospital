package com.hospital.entity;

import java.util.Date;

import lombok.Data;

@Data
public class Bed {
    private Integer bedid;

    private Ward ward;

    private Integer bednumber;

    private Patient patient;

    private Date inputtime;

    private Boolean state;

    
    public Bed(Integer bedid, Ward ward, Integer bednumber, Patient patient, Date inputtime, Boolean state) {
		super();
		this.bedid = bedid;
		this.ward = ward;
		this.bednumber = bednumber;
		this.patient = patient;
		this.inputtime = inputtime;
		this.state = state;
	}

	public Bed() {
		super();
	}

    
}