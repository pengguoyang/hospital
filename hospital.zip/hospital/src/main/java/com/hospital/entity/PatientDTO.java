package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class PatientDTO {
	
	private Integer wardid;
	
	private Integer bedid;
	
	private Integer bednumber;
	
	private Integer patid;

    private String patname;

    private String patsex;

    private Integer patage;
    
    private Date inputtime;

    private String patphone;

    private String familyname;

    private String familyphone;

	public PatientDTO() {
		super();
	}

	public PatientDTO(Integer wardid, Integer bedid, Integer bednumber, Integer patid, String patname, String patsex,
			Integer patage, Date inputtime, String patphone, String familyname, String familyphone) {
		super();
		this.wardid = wardid;
		this.bedid = bedid;
		this.bednumber = bednumber;
		this.patid = patid;
		this.patname = patname;
		this.patsex = patsex;
		this.patage = patage;
		this.inputtime = inputtime;
		this.patphone = patphone;
		this.familyname = familyname;
		this.familyphone = familyphone;
	}
    
}
