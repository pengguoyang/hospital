package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Scheduling {
    private Integer schid;

    private Integer schweek;
    
    private Integer schtime;

    private Staff staff;

	public Scheduling() {
		super();
	}

	public Scheduling(Integer schid, Integer schweek, Integer schtime, Staff staff) {
		super();
		this.schid = schid;
		this.schweek = schweek;
		this.schtime = schtime;
		this.staff = staff;
	}
	
}