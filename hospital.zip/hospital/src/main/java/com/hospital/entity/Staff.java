package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Staff {
    private Integer staid;

    private String staname;
    
    private String password;

    private String stasex;

    private String staphone;

    private Role role;

    private Date staentrydate;

    private Boolean isincumbency;

    private Department department;

	

	public Staff() {
		super();
	}



	public Staff(Integer staid, String staname, String password, String stasex, String staphone, Role role,
			Date staentrydate, Boolean isincumbency, Department department) {
		super();
		this.staid = staid;
		this.staname = staname;
		this.password = password;
		this.stasex = stasex;
		this.staphone = staphone;
		this.role = role;
		this.staentrydate = staentrydate;
		this.isincumbency = isincumbency;
		this.department = department;
	}

    
}