package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Live {
    private Integer liveid;

    private Bed bed;

    private Patient patient;

    private Date inputtime;

    private Date outtime;

    private Integer pay;

	public Live(Integer liveid, Bed bed, Patient patient, Date inputtime, Date outtime, Integer pay) {
		super();
		this.liveid = liveid;
		this.bed = bed;
		this.patient = patient;
		this.inputtime = inputtime;
		this.outtime = outtime;
		this.pay = pay;
	}

	public Live() {
		super();
	}

    
}