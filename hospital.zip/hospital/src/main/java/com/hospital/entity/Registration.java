package com.hospital.entity;

import java.util.Date;

import lombok.Data;
@Data
public class Registration {
    private Integer regid;

    private Department department;

    private Date regdate;

    private Boolean isbreak;

    private Patient patient;

    private Staff staff;

	public Registration(Integer regid, Department department, Date regdate, Boolean isbreak,
			Patient patient, Staff staff) {
		super();
		this.regid = regid;
		this.department = department;
		this.regdate = regdate;
		this.isbreak = isbreak;
		this.patient = patient;
		this.staff = staff;
	}

	public Registration() {
		super();
	}

    
}