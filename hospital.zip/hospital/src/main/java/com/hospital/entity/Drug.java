package com.hospital.entity;

import lombok.Data;

@Data
public class Drug {
    private Integer drugid;

    private String drugname;

    private String drugbrand;

    private String drugnote;

    private String drugtype;

    private Integer drugpay;

	public Drug(Integer drugid, String drugname, String drugbrand, String drugnote, String drugtype, Integer drugpay) {
		super();
		this.drugid = drugid;
		this.drugname = drugname;
		this.drugbrand = drugbrand;
		this.drugnote = drugnote;
		this.drugtype = drugtype;
		this.drugpay = drugpay;
	}

	public Drug() {
		super();
	}

    
}