package com.hospital.entity;

import lombok.Data;

@Data
public class DepartmentIncome {
    private Integer depid;

    private String depname;
    
    private Integer liveIncome;
    
    private Integer prescriptionIncome;
    
    private Integer income;
}