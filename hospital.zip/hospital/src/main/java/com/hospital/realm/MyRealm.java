package com.hospital.realm;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import com.alibaba.druid.sql.ast.SQLPartitionValue.Operator;
import com.hospital.entity.Staff;
import com.hospital.service.StaffService;


public class MyRealm extends AuthorizingRealm{
	@Resource
	private StaffService staffService;
	
	/**
	 * 获取授权信息
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 登陆验证
	 * token:令牌，基于用户名密码的令牌
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		//从令牌中取出手机号
		String staphone = (String)token.getPrincipal().toString();
		String password=new String((char[])token.getCredentials());
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("staphone", staphone);
		map.put("password", password);
		//让Shiro去验证账号密码
		Staff staff= staffService.login(map);
		if(staff==null) {
			throw new AccountException("账号或密码不正确!");
		}
		if(!staff.getIsincumbency()) {
			throw new DisabledAccountException("账号已经停用!");
		}
		SimpleAuthenticationInfo info=new SimpleAuthenticationInfo(staff.getStaphone(),staff.getPassword(),getName());
		return info;
	}

}
