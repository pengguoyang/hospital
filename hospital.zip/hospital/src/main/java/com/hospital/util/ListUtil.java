package com.hospital.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListUtil {
	public static List<String> getdifferentList(List<String> list1,List<String> list2){
		Map<String, Integer> map=new HashMap<String, Integer>();
		List<String> longList=list1;
		List<String> shortList=list2;
		if(list2.size()>list1.size()){
			longList=list2;
			shortList=list1;
		}
		for(String string:shortList){//将shortList放到map中，map的value任意数字即可
			map.put(string,0);
		}
		shortList.clear();//清空shortList，用于存放longList中有map中没有的数据
		Integer in;
		for(String string:longList){
			in=map.get(string);
			if(null==in){
				shortList.add(string);//longList中有map中没有的数据
			}
		}
		return shortList;
		}
}
